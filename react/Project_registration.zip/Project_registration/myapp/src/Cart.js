import React, { Component } from 'react'
import Popup from "reactjs-popup";

export class Cart extends Component {
    onClick = e => {
        this.props.DelUser(e.target.id)
    }
    cartNotify = (item) => {
    if(item)return (
        <Popup
        trigger={
         <button type="button" className="text-left cart btn btn-transparent p-2 d-flex flex-column justify-content-center align-items-center">
            <span className="badge badge-danger m-1 bg-info shadow">
                
            {this.props.Additem.length}
            {console.log((this.props.Additem.map(v=> v[0].First_Name)))}
            </span>
            <i class="fas fa-shopping-cart"></i>

        </button>}
        modal
        closeOnDocumentClick>
        <div className="w-100"> 
            <table className="table table-hover table-sm">
                <thead className="thead-dark p-3">
                    <tr >
                        <th scope="col">#</th>
                        <th className="text-center" scope="col">First Name</th>
                        <th className="text-center" scope="col" >Last Name</th>
                        <th className="text-center" scope="col" >Date of Birth</th>
                        <th className="text-center" scope="col" >Gender</th>
                        <th scope="col">Delete</th>
                    </tr>
                </thead>
                <tbody>
                {this.props.Additem.map((v,i)=> 
                    <tr> 
                        <td> {i+1}.  </td>
                        <td className = "text-center"> {v[0].First_Name}  </td>
                        <td className = "text-center"> {v[0].Last_Name}  </td>
                        <td className = "text-center"> {v[0].DOB}  </td>
                        <td className = "text-center"> {v[0].Gender}  </td>
                        <td  className = "text-center"> 
                                <button  className = "rounded-circle">
                                    <i onClick = {this.onClick} id={i} class="far fa-trash-alt"></i>
                                </button> 
                        </td>                
                    </tr>  )}

                </tbody>
             
            </table>
            <button className="float-right btn btn-info">Purchase</button>
        </div>
        </Popup>
                   
                    
                    )
    return null
    }

    render() {
        
        return (
            <div className = 'float-right mr-5'>
              {this.cartNotify(this.props.Additem.length)}
           </div>
        )
    }
}

export default Cart
