import React, { Component } from "react";

export class LogIn extends Component {
    state = {
      user1 : [{
          fname: ""
      }]
    }
 /*  onSubmit = e => {
    e.preventDefault();
    this.setState({fname: ""})
    console.log(this.state)
  }
 */

  
 handleUname = e => {
     e.preventDefault()
     const val = e.target.value;
     this.setState({
         userName: val
     })
     console.log(this.state)
      if(e.target.value === this.props.users[0].First_Name){
          console.log("successfull")
      }
      else{
          console.log("unsuccessful")
      }
      this.forceUpdate()
  }  
  handleLname = e => {
    e.preventDefault()
    const val = e.target.value;
    this.setState({
        userName: val
    })
    console.log(this.state)
     if(e.target.value === this.props.users[0].Last_Name){
         console.log("successfull")
     }
     else{
         console.log("unsuccessful")
     }
     this.forceUpdate()
 }  
  render() {
    return (
      <div className="bg-light p-3 mt-4 rounded  w-100 shadow ">
        <form className="d-flex flex-wrap align-items-center justify-content-center">
          <div className="form-row">
          <label className="col-4 m-2">UserName</label>
          <input
            type="text"
            name="fname"
            id="fname"
            value = {this.state.fname}
            onChange={this.handleUname}
            className="form-control col-7"
          />
          </div>
          <div className="form-row">
          <label className="col-4 m-2">Password</label>
          <input
            type="text"
            name="lname"
            id="lname"
            value={this.state.lname}
            onChange={this.handleLname}
            className="form-control col-7"
          />
          </div>
         
         <div className="form-row">
         <input
          type="submit"
          value="Login"
          className = "m-1 text-center btn btn-success"
        />

         </div>
        
      </form>
      </div>
      
    );
  }
}

export default LogIn;
