import React, { Component } from "react";

export class AddStudent extends Component {
  state = {
    fname: "",
    lname: "",
    date: "",
    gender: ""
  };
  onSubmit = e => {
    e.preventDefault();
    this.props.AddStu(this.state.fname, this.state.lname, this.state.date, this.state.gender);
    this.setState({ fname: "" });
    this.setState({ lname: "" });
    this.setState({ date: "" });
    this.setState({ gender: "" });

    // console.log("onsubmit works");
  };

  onChange = e => {
    this.setState({ [e.target.name]: e.target.value });
    //console.log(e.target.name, "--", e.target.value);
  };

  render() {
    return (
      <div className="bg-light shadow p-3 mt-3 rounded"> 
      <form onSubmit={this.onSubmit}>
       
        <div className="form-row p-2">
          <div className="col-lg-4"> 
            <label >First Name:</label> 
          </div>
          <div className="col-lg-7">
            <input
              type="text"
              name="fname"
              id="fname"
              value={this.state.fname}
              onChange={this.onChange}
              className="form-control w-100"
              placeholder="Enter you First Name"
            />
          </div>
        </div>
       
       <div className="form-row p-2">
          <div className="col-lg-4"> 
            <label>Last Name:</label>
          </div>
          <div className="col-lg-7">
            <input
              type="text"
              name="lname"
              id="lname"
              value={this.state.lname}
              onChange={this.onChange}
              className="form-control w-100"
              placeholder="Enter you Last Name"

            />
          </div>
        </div>
       
        <div className="form-row p-2">
          <div className="col-lg-4"> 
            <label>DOB:</label>
          </div>
          <div className="col-lg-7">
            <input
            type="date"
            name="date"
            id="date"
            value={this.state.date}
            onChange={this.onChange}
            className="form-control w-100"
            /> 
          </div>
        </div>
       
        <div className="form-row p-2">
          <div className="col-lg-4"> 
            <label >Gender:</label>
          </div>
          <div className="col-lg-3 w-25">
            <div className="input-group-prepend">
            <div className="input-group-text">
              <span>Male</span>
              <input  type="radio"
              name="gender"
              id="male"
              value="Male"
              onClick={this.onChange} 
              required
              aria-label="Radio button for following text input"/>
            </div>
            </div>
          </div>
          <div className="col-lg-3">
            <div className="input-group-prepend">
            <div className="input-group-text">
              <span>female</span>
              <input  type="radio"
              name="gender"
              id="female"
              value="Female"
              onClick={this.onChange} 
              aria-label="Radio button for following text input"/>
            </div>
            </div> 
          </div>
        </div>
        
        <div className="col text-center">
          <input
            type="submit"
            value="Register"
            onClick={this.props.disp}
            className = "col-lg-4 btn btn-success"
          />
        </div>
       
      
       
      </form>
      </div>
    );
  }
}

export default AddStudent;
