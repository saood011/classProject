import React, { Component } from "react";
import AddStudent from "./components/AddStudent";
import uuid from "uuid";
import LogIn from "./components/LogIn";
import UserLIst from "./UserLIst";
import Cart from "./Cart";


class App extends Component {
  state = {
    students: [],
    cart: []
  };

  AddStu = (fname, lname, date, gender) => {
    const newSt = {
      id: uuid.v4(),
      First_Name: fname,
      Last_Name: lname,
      DOB: date,
      Gender: gender,
    };
    //this.setState({ students: newSt });
    this.state.students.push(newSt);
    this.forceUpdate(); 
    /* document.getElementById("list").innerHTML = (this.state.students.map((v,i)=> "<p class = 'p-3 mb-2 bg-info text-white border border-warning '> "+ (i+1)+ ". <b>" + v.First_Name  + "</b> " + v.Last_Name + " / " + v.Gender + " / "+ v.DOB + "<br>").join(" ")+ "</p>" ); */
    console.log(this.state.students)
  };
 
  DelStu = (id) =>{
   this.state.students.splice(id, 1);
    this.forceUpdate();
  }
  DelItemInCart =(id)=>{
    this.state.cart.splice(id,1);
    this.forceUpdate();
  }
 
 /*  DisplayIntoConsole = () => {
    document.getElementById("list").innerHTML = (this.state.students);
    console.log(this.state.students)
} */
AddItem = (id)=> {
 var cart = this.state.students.slice(id, (id+1));
  this.state.cart.push(cart);
  console.log(this.state.cart);
  this.forceUpdate();
}

  render() {
    return (
      <div className="maincomp d-flex flex-wrap ">
        <div className="formArea col-4 pr-0">
        <LogIn users = {this.state.students} />

        <AddStudent AddStu={this.AddStu} disp={this.DisplayIntoConsole}/>
        </div>
     
        <div className="UserList col-8 pl-1 pt-0">
        <Cart Additem ={this.state.cart} DelUser= {this.DelItemInCart} />

        <UserLIst user={this.state.students} DelUser = {this.DelStu} Additem ={this.AddItem} />   

        </div>
        <div className="col-6">


        </div>

      </div>
      
    );
  }
}

export default App;

