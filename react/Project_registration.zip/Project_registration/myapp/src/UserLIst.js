import React, { Component } from 'react';

export class UserLIst extends Component {
   onClick = e => {
       this.props.DelUser(e.target.id)
   }
   addInCart = e => {
       this.props.Additem(e.target.id)
   }
    render() {
        return (
            <table className="table mt-4 shadow">
                <thead className="thead-dark">
                    <tr>
                    <th scope="col">#</th>
                    <th scope="col">First Name</th>
                    <th scope="col" className ="text-center">Last Name</th>
                    <th scope="col" className ="text-center">Date of Birth</th>
                    <th scope="col" className ="text-center">Gender</th>
                    <th scope="col" className ="text-center">Delete</th>
                    <th scope="col" className ="text-center">Add to cart</th>
                    </tr>
                </thead>
                <tbody>
                    {this.props.user.map((v,i)=> <tr className ="bg-light" > 
                    <td className ="text-center">{i+1}.</td>
                    <td className ="text-center">{v.First_Name}</td>
                    <td className ="text-center">{v.Last_Name}</td>
                    <td className ="text-center">{v.DOB}</td>
                    <td className ="text-center">{v.Gender}</td>
                    <td  className = "text-center"> 
                        <button  className = "rounded-circle">
                            <i onClick = {this.onClick} id={i} class="far fa-trash-alt"></i>
                        </button> 
                    </td>
                    <td className="text-center">
                        <button  className = "text-white bg-success border border-success">
                            <i id={i} onClick = {this.addInCart} class="fas fa-cart-plus"></i>
                        </button>
                    </td>
                    </tr>)}
                </tbody>
            </table>

        )
    }
}

export default UserLIst;
