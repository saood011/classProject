import React, { Component } from "react";
import "./App.css";
import "./input";
import Input from "./input";

export class App extends Component {
  state = {
    cal: [],
    result: ""
  };

  valueToCalculate = event => {
    this.state.cal.push(event.target.id);
    console.log(this.state);
    this.forceUpdate();
  };

  Calculate = () => {
    // eslint-disable-next-line
    const result = eval(this.state.cal.join(""));
    this.setState({ result: result });
  };
  clearInput = () => {
    this.setState({ cal: [] });
    this.setState({ result: "" });
  };

  render() {
    return (
      <div>
        <div className="container">
          <Input equation={this.state.cal} result={this.state.result} />

          <table className="table col-3 text-center">
            <tbody>
              <tr>
                <td colSpan="4" className="bg-danger" onClick={this.clearInput}>
                  Clear
                </td>
              </tr>
              <tr>
                <td id="1" onClick={this.valueToCalculate}>
                  1
                </td>
                <td id="1" onClick={this.valueToCalculate}>
                  2
                </td>
                <td id="2" onClick={this.valueToCalculate}>
                  3
                </td>
                <th id="+" onClick={this.valueToCalculate}>
                  +
                </th>
              </tr>
              <tr>
                <td id="4" onClick={this.valueToCalculate}>
                  4
                </td>
                <td id="5" onClick={this.valueToCalculate}>
                  5
                </td>
                <td id="6" onClick={this.valueToCalculate}>
                  6
                </td>
                <th id="-" onClick={this.valueToCalculate}>
                  -
                </th>
              </tr>
              <tr>
                <td id="7" onClick={this.valueToCalculate}>
                  7
                </td>
                <td id="8" onClick={this.valueToCalculate}>
                  8
                </td>
                <td id="9" onClick={this.valueToCalculate}>
                  9
                </td>
                <th id="/" onClick={this.valueToCalculate}>
                  /
                </th>
              </tr>
              <tr>
                <td id="0" onClick={this.valueToCalculate}>
                  0
                </td>
                <td id="." onClick={this.valueToCalculate}>
                  .
                </td>
                <td className="bg-success" onClick={this.Calculate}>
                  =
                </td>
                <th id="*" onClick={this.valueToCalculate}>
                  x
                </th>
              </tr>
            </tbody>
          </table>
        </div>
      </div>
    );
  }
}

export default App;
