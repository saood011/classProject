var lib1 = {
    books: [
        {
        titles: "Javascript",
        author: "Saood",
        publisher:"Akhtar's Publication",
        year: 2050,
        cover: "./java.png"
    },
    {
        titles: "HTML",
        author: "Saood",
        publisher:"Akhtar's Publication",
        year: 2050,
        cover: "./html.png"
    },
    {
        titles: "Node JS",
        author: "Saood",
        publisher:"Akhtar's Publication",
        year: 2050,
        cover: "./node.png"
    },
    {
        titles: "Node JS",
        author: "Saood",
        publisher:"SA7 Publication",
        year: 2050,
        cover: "./node.png"
    },
    {
        titles: "Javascript",
        author: "Saood",
        publisher:"SA7 Publication",
        year: 2050,
        cover: "./java.png"
    },
    {
        titles: "HTML",
        author: "Saood",
        publisher:"Akhtar's Publication",
        year: 2050,
        cover: "./html.png"
    },

        ]
};
$(document).ready(function(){
    var libTemp = $("#myTemplate").html();
    var temple = Handlebars.compile(libTemp);
    
    $("#content").html(temple(lib1));
});

